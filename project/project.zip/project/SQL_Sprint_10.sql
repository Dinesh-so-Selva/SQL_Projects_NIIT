use modelcarsdb;

-- task_1
-- 1
select count(employeenumber) as total_employees from employees;
-- 2
select employeeNumber, firstName, lastName, jobTitle, officeCode, reportsTo from employees;
-- 3
select jobtitle, count(employeenumber) as no_of_employees from employees
group by jobtitle;
-- 4
select employeeNumber, firstName, lastName, jobTitle from employees
where reportsTo is null;
-- 5
select e.employeenumber, e.jobtitle, concat(e.firstName, ' ', e.lastName) AS employeeName , sum(od.quantityOrdered * od.priceEach) as total_sales from employees e
join customers c on e.employeenumber = c.salesrepemployeenumber
join orders o on o.customernumber = c.customernumber
join orderdetails od on od.ordernumber = o.ordernumber
join products p on p.productcode = od.productcode
group by e.employeeNumber, employeeName;
-- 6
select e.employeenumber, e.jobtitle, concat(e.firstName, ' ', e.lastName) AS employeeName , sum(od.quantityOrdered * od.priceEach) as total_sales from employees e
join customers c on e.employeenumber = c.salesrepemployeenumber
join orders o on o.customernumber = c.customernumber
join orderdetails od on od.ordernumber = o.ordernumber
join products p on p.productcode = od.productcode
group by e.employeeNumber, employeeName
order by total_sales desc
limit 1;
-- 7
select e.employeenumber, concat(e.firstname, ' ', e.lastname) as employeename,
       sum(od.quantityordered * od.priceeach) as employee_total_sales
from employees e
join customers c on e.employeenumber = c.salesrepemployeenumber
join orders o on c.customernumber = o.customernumber
join orderdetails od on o.ordernumber = od.ordernumber
group by e.employeenumber, employeename, e.officecode
having employee_total_sales > (
  select avg(total_office_sales)
  from (
    select e2.officecode, sum(od2.quantityordered * od2.priceeach) as total_office_sales
    from employees e2
    join customers c2 on e2.employeenumber = c2.salesrepemployeenumber
    join orders o2 on c2.customernumber = o2.customernumber
    join orderdetails od2 on o2.ordernumber = od2.ordernumber
    where e2.officecode = e.officecode
    group by e2.officecode
  ) as office_avg_sales
);

-- Task 1 Interpretation:
-- This task analyses employee information and their sales contribution.
-- It counts total employees, shows details, groups by job role, and finds top managers.
-- It joins sales data to measure total sales per employee.
-- It highlights top earners and checks which employees sell above their office average.

-- task_2
-- 1
select c.customernumber,c.customername, avg(od.quantityordered * od.priceeach) as avg_order_amount from customers c 
join orders o on c.customernumber = o.customernumber
join orderdetails od on o.ordernumber = od.ordernumber
group by c.customernumber,c.customername;
-- 2
select year(orderdate) as order_year,month(orderdate) as order_month,count(ordernumber) as no_of_orders from orders
group by year(orderdate), month(orderdate)
order by order_year, order_month desc;
-- 3
select ordernumber, orderdate, status
from orders
where status = 'pending';
-- 4
select c.customernumber, c.customername,c.city,c.state, c.country, o.ordernumber, o.orderdate,o.status from customers c 
join orders o on c.customernumber = o.customernumber;
-- 5 
select * from orders
order by orderdate desc
limit 10;
-- 6
select ordernumber , sum(quantityordered * priceeach) as total_sales from orderdetails
group by ordernumber;
-- 7
select ordernumber , sum(quantityordered * priceeach) as total_sales from orderdetails
group by ordernumber
limit 1;
-- 8
select o.ordernumber,o.orderdate,o.status,od.productcode,od.quantityordered,od.priceeach from orders o 
join orderdetails od on o.ordernumber = od.ordernumber
order by od.ordernumber;
-- 9
select od.productcode, p.productname,
       sum(od.quantityordered) as total_quantity_ordered
from orderdetails od
join products p on od.productcode = p.productcode
group by od.productcode, p.productname
order by total_quantity_ordered desc
limit 10;
-- 10
select o.ordernumber,
       sum(od.quantityordered * od.priceeach) as total_revenue
from orders o
join orderdetails od on o.ordernumber = od.ordernumber
group by o.ordernumber;
-- 11
select o.ordernumber,
       sum(od.quantityordered * od.priceeach) as total_revenue
from orders o
join orderdetails od on o.ordernumber = od.ordernumber
group by o.ordernumber
order by total_revenue desc
limit 1;
-- 12
select o.ordernumber, o.orderdate, o.status,
       od.productcode, p.productname, od.quantityordered, od.priceeach
from orders o
join orderdetails od on o.ordernumber = od.ordernumber
join products p on od.productcode = p.productcode
order by o.ordernumber;
-- 13
select ordernumber, orderdate, shippeddate, requireddate, status from orders
where shippeddate>requireddate;
-- 14
select od1.productcode as product1,
       od2.productcode as product2,
       count(od1.productcode) as times_ordered_together
from orderdetails od1
join orderdetails od2 
  on od1.ordernumber = od2.ordernumber 
 and od1.productcode < od2.productcode
group by product1, product2
order by times_ordered_together desc
limit 10;
-- 15
select o.ordernumber,
       sum(od.quantityordered * od.priceeach) as total_revenue
from orders o
join orderdetails od on o.ordernumber = od.ordernumber
group by o.ordernumber
order by total_revenue desc
limit 10;
-- 16
delimiter //
create trigger after_order_insert
after insert on orders
for each row
begin
  declare order_total decimal(10,2);

  select sum(quantityordered * priceeach)
  into order_total
  from orderdetails
  where ordernumber = new.ordernumber;

  update customers
  set creditlimit = creditlimit - order_total
  where customernumber = new.customernumber;
end;
//
delimiter ;

-- 17
delimiter //

create trigger after_orderdetail_insert
after insert on orderdetails
for each row
begin
  insert into product_quantity_log (productcode, old_quantity, new_quantity, action_type)
  values (new.productcode, null, new.quantityordered, 'insert');
end;
//

create trigger after_orderdetail_update
after update on orderdetails
for each row
begin
  insert into product_quantity_log (productcode, old_quantity, new_quantity, action_type)
  values (new.productcode, old.quantityordered, new.quantityordered, 'update');
end;
//
delimiter ;

-- Task 2 Interpretation:
-- This task explores customer orders and sales trends.
-- It calculates average orders, shows pending orders, high-value orders and product combos.
-- It finds top-selling products and recent orders for insights.
-- It also uses triggers to automatically adjust credit limits and log quantity changes for data accuracy.
